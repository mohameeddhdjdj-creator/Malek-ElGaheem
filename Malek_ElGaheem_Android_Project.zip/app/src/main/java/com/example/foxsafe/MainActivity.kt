package com.example.foxsafe

import android.app.Activity
import android.app.AlertDialog
import android.media.MediaPlayer
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("fox_safe_history", MODE_PRIVATE) }
    private lateinit var root: LinearLayout
    private lateinit var numberInput: EditText
    private lateinit var statusText: TextView
    private var page = "login"
    private var mediaPlayer: MediaPlayer? = null
    private val appPassword = "33825252"
    private val bg = Color.rgb(13,17,28)
    private val panel = Color.rgb(25,31,47)
    private val accent = Color.rgb(108,92,231)
    private val green = Color.rgb(46,204,113)
    private val white = Color.rgb(245,247,255)
    private val muted = Color.rgb(164,173,195)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showLogin()
    }

    private fun showLogin() {
        page = "login"
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(24), dp(24), dp(24))
            setBackgroundColor(bg)
        }
        setContentView(root)
        root.addView(text("مَلِك الجَحِيم", 30f, accent, true), margin(0, 0, 0, 8))
        root.addView(text("FOX SAFE • PRIVATE ACCESS", 12f, muted, true), margin(0, 0, 0, 28))
        val box = card()
        box.addView(text("أدخل كلمة المرور", 18f, white, true))
        val pass = EditText(this).apply {
            hint = "Password"
            setHintTextColor(muted)
            setTextColor(white)
            textSize = 18f
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
            setSingleLine(true)
            background = rounded(Color.rgb(38,45,64), 12)
            setPadding(dp(12), dp(12), dp(12), dp(12))
        }
        box.addView(pass, margin(0, 14, 0, 12))
        val message = text("", 13f, Color.rgb(255, 120, 120))
        box.addView(button("دخول", {
            if (pass.text.toString() == appPassword) {
                playStartupSongIfPresent()
                showHome()
            } else {
                message.text = "كلمة المرور غير صحيحة"
                pass.text.clear()
            }
        }), margin(0, 0, 0, 8))
        box.addView(message)
        root.addView(box, margin(0, 0, 0, 18))
        root.addView(text("الصوت يحتاج إضافة ملفك الصوتي إلى res/raw/start_song.mp3", 12f, muted))
    }

    private fun playStartupSongIfPresent() {
        // Add a legally obtained audio file at app/src/main/res/raw/start_song.mp3.
        val audioId = resources.getIdentifier("start_song", "raw", packageName)
        if (audioId == 0) return
        try {
            mediaPlayer?.release()
            mediaPlayer = MediaPlayer.create(this, audioId)?.apply {
                isLooping = false
                start()
            }
        } catch (_: Exception) {
            // The app remains usable if the optional audio asset is missing or invalid.
        }
    }
    private fun dp(v:Int) = (v * resources.displayMetrics.density).toInt()
    private fun rounded(color:Int, radius:Int=18) = GradientDrawable().apply { setColor(color); cornerRadius=dp(radius).toFloat() }
    private fun text(value:String, size:Float, color:Int=white, bold:Boolean=false) = TextView(this).apply {
        text=value; textSize=size; setTextColor(color); if(bold) setTypeface(typeface,Typeface.BOLD)
    }
    private fun button(label:String, action:()->Unit, color:Int=accent) = text(label,15f,white,true).apply {
        gravity=Gravity.CENTER; setPadding(dp(14),dp(14),dp(14),dp(14)); background=rounded(color,14)
        isClickable=true; isFocusable=true; setOnClickListener { action() }
    }
    private fun margin(l:Int,t:Int,r:Int,b:Int) = LinearLayout.LayoutParams(-1,-2).apply { setMargins(dp(l),dp(t),dp(r),dp(b)) }
    private fun card() = LinearLayout(this).apply {
        orientation=LinearLayout.VERTICAL; setPadding(dp(16),dp(16),dp(16),dp(16)); background=rounded(panel)
    }
    private fun setup(title:String, subtitle:String) {
        root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(20),dp(22),dp(20),dp(20)); setBackgroundColor(bg) }
        setContentView(ScrollView(this).apply { isFillViewport=true; addView(root) })
        root.addView(text("مَلِك الجَحِيم",18f,accent,true))
        root.addView(text(title,27f,white,true),margin(0,5,0,4))
        root.addView(text(subtitle,14f,muted),margin(0,0,0,20))
    }
    private fun showHome() {
        page="home"; setup("Number checker","ملك الجحيم • فحص محلي آمن")
        val box=card()
        box.addView(text("PHONE NUMBER",12f,muted,true))
        numberInput=EditText(this).apply {
            hint="+20 1XXXXXXXXX"; setHintTextColor(muted); setTextColor(white); textSize=18f
            inputType=InputType.TYPE_CLASS_PHONE; setSingleLine(true); background=rounded(Color.rgb(38,45,64),12)
            setPadding(dp(12),dp(12),dp(12),dp(12))
        }
        box.addView(numberInput,margin(0,8,0,12))
        box.addView(button("CHECK NUMBER FORMAT"){ checkNumber() })
        statusText=text("Enter a number to check its format.",14f,muted)
        box.addView(statusText,margin(0,12,0,0)); root.addView(box,margin(0,0,0,16))
        val note=card()
        note.addView(text("IMPORTANT",12f,green,true))
        note.addView(text("This app only validates the format locally. It cannot check whether a WhatsApp account is banned, and it does not send reports or contact WhatsApp.",14f,muted),margin(0,8,0,0))
        root.addView(note,margin(0,0,0,18))
        root.addView(button("VIEW HISTORY",{showHistory()},Color.rgb(48,57,79)),margin(0,0,0,10))
        root.addView(button("APP DETAILS & PERMISSIONS",{showDetails()},Color.rgb(48,57,79)))
    }
    private fun normalize(input:String):String {
        var s=input.trim().replace(Regex("[()\\s-]"),"")
        if(s.startsWith("00")) s="+"+s.drop(2)
        return s
    }
    private fun checkNumber() {
        val raw=numberInput.text.toString(); val value=normalize(raw)
        val valid=Regex("^\\+[1-9][0-9]{7,14}$").matches(value)
        statusText.text=if(valid) "✓ FORMAT LOOKS VALID\nNormalized: $value\nThis does not indicate account status."
            else "• CHECK THE FORMAT\nUse country code, e.g. +2010XXXXXXXX."
        statusText.setTextColor(if(valid) green else Color.rgb(255,190,90))
        if(raw.isNotBlank()) saveHistory(raw,value,valid)
    }
    private fun saveHistory(raw:String, normalized:String, valid:Boolean) {
        val arr=JSONArray(prefs.getString("items","[]"))
        val item=JSONObject().apply {
            put("raw",raw); put("normalized",normalized); put("valid",valid)
            put("time",SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.getDefault()).format(Date()))
        }
        val next=JSONArray().apply { put(item); for(i in 0 until minOf(arr.length(),49)) put(arr.getJSONObject(i)) }
        prefs.edit().putString("items",next.toString()).apply()
    }
    private fun showHistory() {
        page="history"; setup("سجل الفحص","محفوظ على هذا الجهاز")
        val arr=JSONArray(prefs.getString("items","[]"))
        if(arr.length()==0) root.addView(text("No checks yet.",15f,muted),margin(0,0,0,16))
        else for(i in 0 until arr.length()) {
            val item=arr.getJSONObject(i); val box=card()
            box.addView(text(item.optString("raw"),17f,white,true))
            box.addView(text(item.optString("time"),12f,muted),margin(0,5,0,3))
            box.addView(text((if(item.optBoolean("valid")) "Format looks valid" else "Format needs checking")+"\n"+item.optString("normalized"),13f,if(item.optBoolean("valid")) green else Color.rgb(255,190,90)))
            root.addView(box,margin(0,0,0,10))
        }
        root.addView(button("CLEAR HISTORY",{
            AlertDialog.Builder(this).setTitle("Clear history?").setMessage("This only removes saved checks from this device.")
                .setNegativeButton("Cancel",null).setPositiveButton("Clear"){_,_->prefs.edit().remove("items").apply();showHistory()}.show()
        },Color.rgb(143,55,70)),margin(0,8,0,10))
        root.addView(button("BACK",{showHome()},Color.rgb(48,57,79)))
    }
    private fun showDetails() {
        page="details"; setup("تفاصيل البرنامج","الخصوصية والصلاحيات")
        val box=card()
        box.addView(text("FOX Safe • Version 1.0",17f,white,true))
        box.addView(text("Purpose",13f,accent,true),margin(0,14,0,4))
        box.addView(text("Validates international phone-number formatting and stores a local history.",14f,muted))
        box.addView(text("Permissions",13f,accent,true),margin(0,14,0,4))
        box.addView(text("No Android permissions are requested. No contacts, SMS, call logs, accessibility service, or network access are used.",14f,muted))
        box.addView(text("Privacy",13f,accent,true),margin(0,14,0,4))
        box.addView(text("History is stored in this app's private preferences on this device. Clear it from the History screen.",14f,muted))
        box.addView(text("Limitations",13f,accent,true),margin(0,14,0,4))
        box.addView(text("The app cannot determine WhatsApp ban status or trigger bans. A valid number format only means the text matches an international-number pattern.",14f,muted))
        root.addView(box,margin(0,0,0,16)); root.addView(button("BACK",{showHome()},Color.rgb(48,57,79)))
    }
    override fun onDestroy() {
        mediaPlayer?.release()
        mediaPlayer = null
        super.onDestroy()
    }

    @Deprecated("Deprecated in Android API")
    override fun onBackPressed() {
        when(page) {
            "history", "details" -> showHome()
            "home" -> showLogin()
            else -> super.onBackPressed()
        }
    }
}
