# ملك الجحيم — Android project

Android Studio project with a password gate, dark interface, phone-number format validation,
local history, and app details/privacy page.

## Password
The app currently checks the locally configured password `33825252`.
This is a basic in-app gate, not strong security: anyone who can inspect the APK may recover it.

## Optional startup audio
To play audio after successful password entry, add an audio file you have permission to use
at `app/src/main/res/raw/start_song.mp3` (create the `raw` folder if needed).
The app checks for this resource and plays it if present. The song file is not included.
Use a copy you own or are licensed to use.

## Build an APK
1. Install Android Studio stable and Android SDK Platform 35.
2. Open this folder in Android Studio.
3. Allow Gradle sync to finish (internet may be needed to download Gradle plugins).
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Find the APK at `app/build/outputs/apk/debug/app-debug.apk`.

## Features
- Password screen
- Optional startup audio asset
- International phone-number format validation
- Local check history with clear option
- App details and permissions transparency
- No network permission, contacts access, reports, or ban functionality
